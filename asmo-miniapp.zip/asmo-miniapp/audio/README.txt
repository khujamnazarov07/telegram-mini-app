Audio fayllarni shu papkaga 001.mp3 ... 099.mp3 nomi bilan joylang.
